package com.example.parser.provider.vector;

import com.example.parser.model.Vector;

import java.util.List;

public interface VectorProvider<T> {

    List<Vector> getVectorData(T apiRequest);

}
