package com.example.parser.provider.vector;

import com.example.parser.model.Vector;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import java.util.List;

@Component
@RequiredArgsConstructor(onConstructor_ = @Autowired)
public class LlmVectorProvider implements VectorProvider<VectorRequest> {

    private final RestTemplate restTemplate;
    @Value("${nlm.vectorization.service}")
    private String vectorizationService;

    @Override
    public List<Vector> getVectorData(VectorRequest apiRequest) {
        try {
        System.out.println("processing requests");
        String response = restTemplate.postForEntity(
                        vectorizationService,
                        apiRequest.getData(),
                        String.class)
                .getBody();
            return new ObjectMapper().readValue(response, new VectorTypeReference());
        } catch (JsonProcessingException e) {
            throw new RuntimeException(e);
        }
    }

    private static class VectorTypeReference extends TypeReference<List<Vector>> {

    }
}
