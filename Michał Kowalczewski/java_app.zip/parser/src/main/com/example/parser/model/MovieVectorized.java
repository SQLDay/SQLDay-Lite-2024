package com.example.parser.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class MovieVectorized {
    private String id;
    private String title;
    private String rating;
    private String runtime;
    private String genre;
    private String metascore;
    private String plot;
    private String directors;
    private String stars;
    private String votes;
    private String gross;
    private String link;
    private Vector vector;

    public MovieVectorized(Movie movie, Vector vector) {
        this.id = movie.getId();
        this.title = movie.getTitle();
        this.rating = movie.getRating();
        this.runtime = movie.getRuntime();
        this.genre = movie.getGenre();
        this.metascore = movie.getMetascore();
        this.plot = movie.getPlot();
        this.directors = movie.getDirectors();
        this.stars = movie.getStars();
        this.votes = movie.getVotes();
        this.gross = movie.getGross();
        this.link = movie.getLink();
        this.vector = vector;
    }
}
