package com.example.parser.controller;

import com.example.parser.api.MovieScoredResponse;
import com.example.parser.model.Movie;
import com.example.parser.model.Vector;
import com.example.parser.provider.vector.VectorRequest;
import com.example.parser.provider.vector.VectorProvider;
import com.example.parser.service.MovieService;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@AllArgsConstructor(onConstructor_ = @Autowired)
public class MovieController {

    private MovieService movieService;
    private VectorProvider<VectorRequest> vectorProvider;

    @PutMapping("loadCsvToElastic")
    public String loadCsvToElastic() {
        movieService.saveToElastic();
        return "Done";
    }

    @PostMapping("vectorize")
    public String vectorizeMovies() {
        movieService.vectorizeMovies();
        return "Done";
    }

    @GetMapping("getVectors")
    public List<Vector> loadCsvToElastic(VectorRequest vectorRequest) {
        return vectorProvider.getVectorData(vectorRequest);
    }

    @GetMapping("moviesKnnTitlePlot")
    public List<MovieScoredResponse> getMoviesKnnTitlePlot(@RequestParam("query") String query) {
        return movieService.getMoviesKnn(query, "vectorized-movies");
    }

    @GetMapping("moviesKnnTitlePlotFilterRating")
    public List<MovieScoredResponse> getMoviesKnnTitlePlot(@RequestParam("query") String query, @RequestParam("rating") Double rating) {
        return movieService.getMoviesKnnFiltered(query, "vectorized-movies", rating);
    }

    @GetMapping("moviesKnnTitle")
    public List<MovieScoredResponse> getMoviesKnnTitle(@RequestParam("query") String query) {
        return movieService.getMoviesKnn(query, "vectorized-movie-titles");
    }

    @GetMapping("moviesKnnPlot")
    public List<MovieScoredResponse> getMoviesKnnPlot(@RequestParam("query") String query) {
        return movieService.getMoviesKnn(query, "vectorized-movie-plots");
    }

    @GetMapping("moviesKnnWithRatins")
    public List<MovieScoredResponse> getMoviesKnnWithRatings(@RequestParam("query") String query) {
        return movieService.getMoviesKnn(query, "vectorized-movies-mix");
    }

    @GetMapping("moviesFuzzy")
    public List<MovieScoredResponse> getMoviesFuzzy(@RequestParam("query") String query) {
        return movieService.getMoviesFuzzy(query);
    }

}
