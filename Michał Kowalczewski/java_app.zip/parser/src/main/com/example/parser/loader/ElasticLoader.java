package com.example.parser.loader;

import co.elastic.clients.elasticsearch.ElasticsearchClient;
import co.elastic.clients.elasticsearch.core.CreateRequest;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.IOException;

@Component
@AllArgsConstructor(onConstructor_ = @Autowired)
public class ElasticLoader<T> {

    private final ElasticsearchClient client;

    public void loadToElastic(T t, String id, String index) {
        try {
            client.create(CreateRequest.of(
                    createRequestBuilder ->
                        createRequestBuilder.index(index)
                                .document(t)
                                .id(id)
                    )

            );
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

}
