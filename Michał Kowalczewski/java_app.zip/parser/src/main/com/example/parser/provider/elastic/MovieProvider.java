package com.example.parser.provider.elastic;

import com.example.parser.api.MovieScoredResponse;
import com.example.parser.model.Movie;

import java.util.List;

public interface MovieProvider {

    List<Movie> getMoviesFromCsv(String path);
    List<Movie> getMoviesPageFromElastic(String startingId);
    List<MovieScoredResponse> getMoviesKnn(String query, String index);
    List<MovieScoredResponse> getMoviesKnnFiltered(String query, String index, Double rating);
    List<MovieScoredResponse> getMoviesFuzzy(String query);

}
