package com.example.parser.provider.elastic;

import co.elastic.clients.elasticsearch.ElasticsearchClient;
import co.elastic.clients.elasticsearch._types.FieldSort;
import co.elastic.clients.elasticsearch._types.KnnSearch;
import co.elastic.clients.elasticsearch._types.SortOrder;
import co.elastic.clients.elasticsearch._types.query_dsl.Query;
import co.elastic.clients.elasticsearch.core.SearchRequest;
import co.elastic.clients.elasticsearch.core.search.Hit;
import co.elastic.clients.util.Pair;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Component
@RequiredArgsConstructor(onConstructor_ = @Autowired)
public class ElasticRestService<T> {

    private final ElasticsearchClient client;
    
    private static final int NUMBER_OF_RECORDS_FOR_SCROLL = 100;

    public List<T> getAllDataFromIndex(Class<T> returnDataType, String index, String lastId) throws IOException {
        return client.search(SearchRequest.of(
                                searchRequestBuilder -> searchRequestBuilder
                                        .index(index)
                                        .size(500)
                                        .query(
                                                Query.of(
                                                        queryBuilder -> queryBuilder.matchAll(
                                                                builder -> builder
                                                        )
                                                )
                                        )
                                        .sort(sortBuilder -> sortBuilder.field(builder -> builder.field("id.keyword").order(SortOrder.Asc)))
                                        .searchAfter(afterBuilder -> afterBuilder.stringValue(lastId))
                        ),
                        returnDataType
                ).hits().hits().stream().map(Hit::source)
                .collect(Collectors.toList());
    }

    public List<Pair<Double, T>> findUsingFuzzySearch(Class<T> returnDataType, String index, String query) throws IOException {
        return client.search(SearchRequest.of(
                                searchRequestBuilder -> searchRequestBuilder
                                        .index(index)
                                        .size(10)
                                        .query(Query.of(
                                                queryBuilder -> queryBuilder
                                                        .multiMatch(multiMatchQueryBuilder -> multiMatchQueryBuilder
                                                                .fuzziness("1")
                                                                .query(query))
                                        ))
                        ),
                        returnDataType).hits().hits().stream().map(tHit -> new Pair<>(tHit.score(), tHit.source()))
                .collect(Collectors.toList());
    }

    public List<Pair<Double, T>> findNearestNeighbors(Class<T> returnDataType, String index, List<Float> predictedValuesList, int size, Optional<Query> filter) throws IOException {
        SearchRequest searchRequest = SearchRequest.of(searchBuidler ->
                searchBuidler.knn(builder ->
                                buildKnnQuery(builder, size, 100, predictedValuesList, filter))
                        .index(index)
        );
        return client.search(
                        searchRequest,
                        returnDataType
                ).hits().hits().stream().map(tHit -> new Pair<>(tHit.score(), tHit.source()))
                .toList();
    }

    private static KnnSearch.Builder buildKnnQuery(KnnSearch.Builder builder, int size, int value, List<Float> predictedValuesList, Optional<Query> filter) {
        builder.k(size)
                .numCandidates(value)
                .queryVector(predictedValuesList)
                .field("vector.values");
        filter.ifPresent(builder::filter);
        return builder;
    }
}
