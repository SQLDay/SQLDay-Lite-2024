package com.example.parser.service;

import com.example.parser.api.MovieScoredResponse;
import com.example.parser.loader.ElasticLoader;
import com.example.parser.model.Movie;
import com.example.parser.model.MovieVectorized;
import com.example.parser.model.Vector;
import com.example.parser.provider.elastic.MovieProvider;
import com.example.parser.provider.vector.VectorRequest;
import com.example.parser.provider.vector.VectorProvider;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.IntStream;
import java.util.stream.Stream;

@Component
@AllArgsConstructor(onConstructor_ = @Autowired)
public class MovieService {

    private final MovieProvider movieProvider;
    private final ElasticLoader<Movie> moviesLoader;
    private final ElasticLoader<MovieVectorized> vectorizedMoviesLoader;
    private final VectorProvider<VectorRequest> vectorProvider;

    public void saveToElastic() {
        movieProvider.getMoviesFromCsv("src/main/resources/Top_10000_Movies_IMDb.csv")
                .forEach(movie -> moviesLoader.loadToElastic(movie, movie.getId(), "movies"));
    }

    public void vectorizeMovies() {
        List<Movie> moviesPage = movieProvider.getMoviesPageFromElastic("");
        while (!moviesPage.isEmpty()) {
            System.out.println(LocalDateTime.now() + " 500 requestów");
            List<String> queriesToBeVectorized =  moviesPage.stream()
                    .map(movie -> "Title: " + movie.getTitle() + "Rating: " + movie.getRating() + "Plot: " + movie.getPlot())
                    .toList();

            List<Vector> vectors = vectorProvider.getVectorData(new VectorRequest(queriesToBeVectorized));
            getMovieVectorizedMovies(moviesPage, vectors)
                    .forEach(movieVectorized -> vectorizedMoviesLoader.loadToElastic(movieVectorized, movieVectorized.getId(), "vectorized-movies-mix"));
            Movie lastMovie = moviesPage.getLast();
            moviesPage = movieProvider.getMoviesPageFromElastic(lastMovie.getId());

        }
        System.out.println("THE END");
    }

    private Stream<MovieVectorized> getMovieVectorizedMovies(List<Movie> moviesPage, List<Vector> vectors) {
        return IntStream.range(0, moviesPage.size())
                .mapToObj(value -> mapToMovieVectorized(moviesPage, vectors, value));
    }

    private MovieVectorized mapToMovieVectorized(List<Movie> movies, List<Vector> vectors, int value) {
        return new MovieVectorized(movies.get(value), vectors.get(value));
    }

    public List<MovieScoredResponse> getMoviesKnn(String query, String index) {
        return movieProvider.getMoviesKnn(query, index);
    }

    public List<MovieScoredResponse> getMoviesKnnFiltered(String query, String index, Double rating) {
        return movieProvider.getMoviesKnnFiltered(query, index, rating);
    }

    public List<MovieScoredResponse> getMoviesFuzzy(String query) {
        return movieProvider.getMoviesFuzzy(query);
    }
}
