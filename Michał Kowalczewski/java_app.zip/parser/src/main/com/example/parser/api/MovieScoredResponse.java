package com.example.parser.api;

import com.example.parser.model.Movie;

public record MovieScoredResponse(Double score, Movie movie) {}
