package com.example.parser.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.opencsv.bean.CsvBindByName;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class Movie {

    @CsvBindByName
    private String id;
    @CsvBindByName
    private String title;
    @CsvBindByName
    private String rating;
    @CsvBindByName
    private String runtime;
    @CsvBindByName
    private String genre;
    @CsvBindByName
    private String metascore;
    @CsvBindByName
    private String plot;
    @CsvBindByName
    private String directors;
    @CsvBindByName
    private String stars;
    @CsvBindByName
    private String votes;
    @CsvBindByName
    private String gross;
    @CsvBindByName
    private String link;

}
