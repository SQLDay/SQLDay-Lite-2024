package com.example.parser.provider.elastic;

import co.elastic.clients.elasticsearch._types.query_dsl.Query;
import co.elastic.clients.util.Pair;
import com.example.parser.api.MovieScoredResponse;
import com.example.parser.model.Movie;
import com.example.parser.model.Vector;
import com.example.parser.provider.vector.VectorProvider;
import com.example.parser.provider.vector.VectorRequest;
import com.opencsv.bean.CsvToBeanBuilder;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.List;
import java.util.Optional;

@Component
@AllArgsConstructor(onConstructor_ = @Autowired)
public class MovieProviderImpl implements MovieProvider {

    private final ElasticRestService<Movie> moviesProvider;
    private final VectorProvider<VectorRequest> vectorProvider;

    @Override
    public List<Movie> getMoviesFromCsv(String path) {
        try {
            return new CsvToBeanBuilder(new FileReader("src/main/resources/Top_10000_Movies_IMDb.csv"))
                    .withType(Movie.class).build().parse();
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public List<Movie> getMoviesPageFromElastic(String startingId) {
        try {
            return moviesProvider.getAllDataFromIndex(Movie.class, "movies", startingId);
        } catch (IOException e) {
            return List.of();
        }
    }

    public List<MovieScoredResponse> getMoviesKnn(String query, String index) {
        Vector queryVector = vectorProvider.getVectorData(new VectorRequest(List.of(query))).get(0);
        try {
            return moviesProvider.findNearestNeighbors(Movie.class, index, queryVector.getValues(), 10, Optional.empty()).stream()
                    .map(this::mapToSCoredResponse)
                    .toList();
        } catch (IOException e) {
            return List.of();
        }
    }

    public List<MovieScoredResponse> getMoviesKnnFiltered(String query, String index, Double rating) {
        Vector queryVector = vectorProvider.getVectorData(new VectorRequest(List.of(query))).get(0);
        try {
            return moviesProvider.findNearestNeighbors(Movie.class, index, queryVector.getValues(), 10,
                            Optional.of(new Query.Builder().bool(builder -> builder.filter(builder1 -> builder1.range(builder2 -> builder2.term(builder3 -> builder3.field("rating").gt(rating.toString()))))).build())
                    ).stream()
                    .map(this::mapToSCoredResponse)
                    .toList();
        } catch (IOException e) {
            return List.of();
        }
    }

    @Override
    public List<MovieScoredResponse> getMoviesFuzzy(String query) {
        try {
            return moviesProvider.findUsingFuzzySearch(Movie.class, "vectorized-movies", query).stream()
                    .map(this::mapToSCoredResponse)
                    .toList();
        } catch (IOException e) {
            return List.of();
        }
    }

    private MovieScoredResponse mapToSCoredResponse(Pair<Double, Movie> doubleMoviePair) {
        return new MovieScoredResponse(doubleMoviePair.key(), doubleMoviePair.value());
    }
}
